import { Component, OnInit } from '@angular/core';

import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
  employees: Employee[];

  constructor(private employeeService: EmployeeService) { }

  ngOnInit() {
    this.getEmployees();
  }

  getEmployees(): void {
    this.employeeService.getEmployees()
    .subscribe(employees => this.employees = employees);
  }

  add(name: string,employeeLastName: string,mailId: string,phoneNumber: number,password:string,role:string,gender:string): void {
    name = name.trim();
    employeeLastName=employeeLastName.trim();
    mailId=mailId.trim();
    phoneNumber=0;
    password=password.trim();
    role=role.trim();
    gender=gender.trim();
    status='INACTIVE';
    if (!name) { return; }
    if (!employeeLastName) { return; }
    if (!mailId) { return; }
    if (!phoneNumber) { return; }
    if (!password) { return; }
    if (!role) { return; }
    if (!gender) { return; }
    this.employeeService.addEmployee({name,employeeLastName,mailId,phoneNumber,password,role,gender,status} as Employee)
      .subscribe(employee => {
        this.employees.push(employee);
      });
  }

  delete(employee: Employee): void {
    this.employees = this.employees.filter(h => h !== employee);
    this.employeeService.deleteEmployee(employee).subscribe();
  }

}