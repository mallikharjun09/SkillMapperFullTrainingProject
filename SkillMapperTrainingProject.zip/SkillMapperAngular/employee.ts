export class Employee {
  id: number;
  name: string;
  employeeLastName: string;
  mailId:string;
  password:string;
  phoneNumber:number;
  gender:string;
  role:string;
  status:string;
}